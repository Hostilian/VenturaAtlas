# Competitor analysis Prompt — European Food Knowledge Graph

You are working on **European Food Knowledge Graph**.

## Verified context supplied by the idea record
- Concept: Evidence layer connecting products, ingredients, origins, regulations, and sellers.
- Primary customer: independent builders
- Problem: Domain data is inconsistent, duplicated, unversioned, and difficult for software or AI to reason over.
- Proposed product: Evidence layer connecting products, ingredients, origins, regulations, and sellers. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: API and enterprise licensing
- Main risk: unclear first wedge
- Current confidence: 8.5/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Identify direct, indirect, DIY, open-source, platform-native, and do-nothing competitors. Compare workflow, pricing, distribution, data, switching costs, failure modes, and likely responses. Do not infer features from marketing headlines.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
