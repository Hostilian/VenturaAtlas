# Risk and pre-mortem Prompt — Autonomous Experiment Factory

You are working on **Autonomous Experiment Factory**.

## Verified context supplied by the idea record
- Concept: Convert assumptions into cheap tests and update rankings from real outcomes.
- Primary customer: independent builders
- Problem: Research produces documents but often fails to produce decisions, experiments, or learning loops.
- Proposed product: Convert assumptions into cheap tests and update rankings from real outcomes. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: team subscriptions and research credits
- Main risk: unclear first wedge
- Current confidence: 9.3/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Assume failure after 12 months. Identify earliest warning, false assumption, lost time/money, product/market/distribution/technical/legal/platform/support risks, reusable assets, mitigations, month-two detection, and explicit abandon conditions.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
