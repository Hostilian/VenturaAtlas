# Security and privacy review Prompt — Marketplace Trust Layer

You are working on **Marketplace Trust Layer**.

## Verified context supplied by the idea record
- Concept: Seller verification, review integrity, disputes, provenance, and risk scoring.
- Primary customer: independent builders
- Problem: Businesses repeat verification and evidence workflows manually with inconsistent quality.
- Proposed product: Seller verification, review integrity, disputes, provenance, and risk scoring. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: subscription and usage fees
- Main risk: unclear first wedge
- Current confidence: 9.0/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Perform threat modelling and privacy review across inputs, uploads, identity, payments, integrations, model calls, logs, exports, retention, deletion, abuse, prompt injection, authorization, and incident handling. Separate technical controls from legal conclusions.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
