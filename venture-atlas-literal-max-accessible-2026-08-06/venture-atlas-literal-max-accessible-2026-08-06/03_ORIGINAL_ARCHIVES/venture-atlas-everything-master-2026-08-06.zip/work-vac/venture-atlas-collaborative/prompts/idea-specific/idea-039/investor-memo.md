# Investor memo Prompt — Local Event & Early-Bird Radar

You are working on **Local Event & Early-Bird Radar**.

## Verified context supplied by the idea record
- Concept: Track official event announcements, ticket tiers, discounts, and venue calendars.
- Primary customer: independent builders
- Problem: Local, urgent opportunities are scattered and hard to verify before they expire.
- Proposed product: Track official event announcements, ticket tiers, discounts, and venue calendars. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: premium alerts; sponsors; referrals
- Main risk: unclear first wedge
- Current confidence: 9.1/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Write a skeptical investment memo with thesis, customer, market, timing, product, distribution, economics, moat, evidence, risks, milestones, capital needs, outcomes, and reasons not to invest. Do not inflate total addressable market.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
