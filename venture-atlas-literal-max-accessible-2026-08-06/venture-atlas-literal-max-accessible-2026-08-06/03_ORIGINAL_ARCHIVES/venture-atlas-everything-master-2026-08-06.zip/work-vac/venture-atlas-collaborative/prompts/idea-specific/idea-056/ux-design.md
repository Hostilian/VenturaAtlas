# UX design Prompt — Erasmus Course Rescue Pack

You are working on **Erasmus Course Rescue Pack**.

## Verified context supplied by the idea record
- Concept: Turns course catalogues and home-university requirements into an evidence table and coordinator-ready fallback shortlist.
- Primary customer: Erasmus students
- Problem: Exchange students face changing course availability, prerequisites, recognition uncertainty, and multi-party approval under deadlines.
- Proposed product: A paid, non-guaranteed evidence pack with course mappings, gaps, fallback options, and precise questions for coordinators.
- Revenue paths: one-time student packs; institutional licences; seasonal bundles
- Main risk: price-sensitive users
- Current confidence: 7.0/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Design a responsive, accessible, low-friction UX with information architecture, user journey, wireframe descriptions, content hierarchy, empty/error/loading states, trust evidence, approval gates, keyboard behavior, and mobile constraints.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
