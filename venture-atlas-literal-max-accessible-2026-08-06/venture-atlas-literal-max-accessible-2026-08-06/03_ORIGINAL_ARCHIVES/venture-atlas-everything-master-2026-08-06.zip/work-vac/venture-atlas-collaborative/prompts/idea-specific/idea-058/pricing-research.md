# Pricing research Prompt — Small-Tour Empty-Seat Rescue Circle

You are working on **Small-Tour Empty-Seat Rescue Circle**.

## Verified context supplied by the idea record
- Concept: Routes verified last-minute availability to nearby travelers and partner properties.
- Primary customer: small tour operators
- Problem: Unused tour capacity expires daily while nearby travelers may be ready to book at short notice.
- Proposed product: A standardized opt-in availability feed distributed through local properties with tracked referrals and no inventory ownership.
- Revenue paths: booking commission; operator subscription; sponsor placement
- Main risk: two-sided coordination
- Current confidence: 7.1/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Investigate current alternatives, buyer budget, value metric, price sensitivity, packaging, free substitutes, usage cost, enterprise requirements, and refund risk. Design real pricing tests; do not treat survey willingness as payment evidence.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
