# Go-to-market Prompt — ProofRail — AI Work Acceptance Gate

You are working on **ProofRail — AI Work Acceptance Gate**.

## Verified context supplied by the idea record
- Concept: Provider-neutral proof and acceptance between AI agents and merge/release.
- Primary customer: AI-native engineering teams
- Problem: AI coding agents can claim completion without proving scope, tests, repository rules, or release safety.
- Proposed product: Provider-neutral proof and acceptance between AI agents and merge/release. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: hosted team plans; self-hosted enterprise licenses; policy packs; usage-based verification
- Main risk: unclear first wedge
- Current confidence: 8.6/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Choose one beachhead and design positioning, offer, first 10/100 customers, outbound, inbound, partners, product-led loops, onboarding, retention, expansion, channel economics, sales assets, and a weekly experiment cadence.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
