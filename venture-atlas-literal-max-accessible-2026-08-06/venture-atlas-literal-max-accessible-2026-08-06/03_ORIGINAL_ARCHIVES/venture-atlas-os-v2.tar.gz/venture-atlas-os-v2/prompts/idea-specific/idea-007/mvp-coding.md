# MVP coding Prompt — Creator Video Automation Pipeline

You are working on **Creator Video Automation Pipeline**.

## Verified context supplied by the idea record
- Concept: Owned-media pipeline from research and scripting through editing and publishing packages.
- Primary customer: independent builders
- Problem: Content production repeats expensive manual steps and loses provenance across platforms.
- Proposed product: Owned-media pipeline from research and scripting through editing and publishing packages. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: subscriptions; rendering credits; services
- Main risk: unclear first wedge
- Current confidence: 8.0/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Act as a coding agent. Inspect the repository first, establish tests and acceptance criteria, implement one complete vertical slice, keep changes reviewable, run validations, document limitations, and stop before irreversible external actions.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
