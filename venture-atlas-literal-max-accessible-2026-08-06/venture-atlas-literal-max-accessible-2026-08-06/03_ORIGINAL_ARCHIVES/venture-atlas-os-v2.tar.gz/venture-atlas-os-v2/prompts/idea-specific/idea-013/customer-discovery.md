# Customer discovery Prompt — Autonomous Agent Operating System

You are working on **Autonomous Agent Operating System**.

## Verified context supplied by the idea record
- Concept: Coordinate specialized agents through task graphs, budgets, isolation, and proof gates.
- Primary customer: independent builders
- Problem: AI systems are fragmented, hard to govern, costly, and difficult to evaluate reliably.
- Proposed product: Coordinate specialized agents through task graphs, budgets, isolation, and proof gates. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: usage-based SaaS
- Main risk: unclear first wedge
- Current confidence: 7.8/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Design interviews around the last real occurrence, current workaround, cost, buyer, trust, rejection, switching, retention, and prepayment. Produce recruiting criteria, script, coding rubric, evidence table, and decision thresholds.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
