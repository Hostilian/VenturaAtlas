# Operations and automation Prompt — Commerce Knowledge Graph Platform

You are working on **Commerce Knowledge Graph Platform**.

## Verified context supplied by the idea record
- Concept: Connect catalogs, content, inventory, policies, users, and transactions for AI commerce.
- Primary customer: independent builders
- Problem: Domain data is inconsistent, duplicated, unversioned, and difficult for software or AI to reason over.
- Proposed product: Connect catalogs, content, inventory, policies, users, and transactions for AI commerce. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: API and enterprise licensing
- Main risk: unclear first wedge
- Current confidence: 8.4/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Map every recurring operation, owner, input/output, SLA, exception, control, metric, and automation threshold. Create SOPs for onboarding, delivery, review, billing, support, data updates, incidents, and weekly quality checks.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
