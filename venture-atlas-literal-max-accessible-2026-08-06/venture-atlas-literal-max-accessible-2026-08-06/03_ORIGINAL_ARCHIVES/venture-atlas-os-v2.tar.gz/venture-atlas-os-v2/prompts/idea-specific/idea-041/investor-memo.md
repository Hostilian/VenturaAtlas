# Investor memo Prompt — Living European Food Atlas

You are working on **Living European Food Atlas**.

## Verified context supplied by the idea record
- Concept: Map-led catalog connecting regions, foods, producers, stories, and purchasing.
- Primary customer: food explorers
- Problem: Food discovery, culture, evidence, and commerce are separated across weakly linked sources.
- Proposed product: Map-led catalog connecting regions, foods, producers, stories, and purchasing. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: commerce commission; premium guides; tourism partnerships; data licensing
- Main risk: unclear first wedge
- Current confidence: 7.8/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Write a skeptical investment memo with thesis, customer, market, timing, product, distribution, economics, moat, evidence, risks, milestones, capital needs, outcomes, and reasons not to invest. Do not inflate total addressable market.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
