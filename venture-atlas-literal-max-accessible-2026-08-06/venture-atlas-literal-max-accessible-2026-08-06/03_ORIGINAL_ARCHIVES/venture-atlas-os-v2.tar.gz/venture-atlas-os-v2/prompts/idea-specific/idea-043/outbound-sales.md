# Outbound sales Prompt — Regional Commerce Launchpad

You are working on **Regional Commerce Launchpad**.

## Verified context supplied by the idea record
- Concept: Launch one-region specialty marketplaces with reusable commerce and trust modules.
- Primary customer: independent builders
- Problem: Supply and demand remain fragmented while trust, data quality, and cross-border operations are weak.
- Proposed product: Launch one-region specialty marketplaces with reusable commerce and trust modules. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: transaction take rate and seller plans
- Main risk: unclear first wedge
- Current confidence: 8.4/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Create a small, personalized outreach sequence for qualified buyers showing the triggering evidence. Include list criteria, first message, follow-ups, discovery call, paid pilot close, objection handling, and ethical stop rules. Avoid spam automation.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
