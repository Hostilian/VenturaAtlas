# Customer discovery Prompt — SSD Storage Culprit Analyzer

You are working on **SSD Storage Culprit Analyzer**.

## Verified context supplied by the idea record
- Concept: Local read-only analysis of storage growth, duplicates, caches, and safe cleanup.
- Primary customer: developers
- Problem: Users cannot safely understand and control complex local computer resources.
- Proposed product: Local read-only analysis of storage growth, duplicates, caches, and safe cleanup. The product should keep inputs, evidence, decisions, outputs, and change history structured and auditable.
- Revenue paths: desktop license and support
- Main risk: dangerous deletion
- Current confidence: 8.9/10

## Evidence rules
Separate source facts, user-provided claims, analyst assumptions, calculations, projections, and unknowns. Do not invent market sizes, competitors, prices, laws, APIs, customer quotes, traction, or completed implementation. Recheck every current claim using primary sources. Show negative evidence. Cite the claim each source supports. Preserve uncertainty and stop when access is insufficient.

## Assignment
Design interviews around the last real occurrence, current workaround, cost, buyer, trust, rejection, switching, retention, and prepayment. Produce recruiting criteria, script, coding rubric, evidence table, and decision thresholds.

## Required output
Return decisions, evidence table, assumptions, unknowns, risks, acceptance criteria, and the next falsification step.
