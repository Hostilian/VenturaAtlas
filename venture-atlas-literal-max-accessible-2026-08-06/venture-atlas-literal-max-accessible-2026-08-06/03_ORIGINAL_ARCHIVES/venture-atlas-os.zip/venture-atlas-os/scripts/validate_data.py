from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[1];E=[]
def load(p):
 try:return json.loads((R/p).read_text(encoding='utf-8'))
 except Exception as e:E.append(f'{p}: {e}');return []
I=load('data/ideas.json');P=load('data/prompts.json');W=load('data/ranking-framework.json').get('weights',{})
ids=set();pids={p.get('id') for p in P}
req={'id','title','oneLiner','category','stage','tags','problem','solution','customers','monetization','moat','aiBuildPlan','next48Hours','scores','confidence','estimatedMvp','capitalLevel','risks','source','relatedPrompts'}
for n,i in enumerate(I):
 if req-set(i):E.append(f'idea {n} missing {sorted(req-set(i))}')
 if i.get('id') in ids:E.append(f'duplicate {i.get("id")}')
 ids.add(i.get('id'))
 for k in W:
  v=i.get('scores',{}).get(k)
  if not isinstance(v,(int,float)) or not 0<=v<=10:E.append(f'{i.get("id")} invalid {k}')
 for p in i.get('relatedPrompts',[]):
  if p not in pids:E.append(f'{i.get("id")} unknown prompt {p}')
for p in P:
 if not (R/p.get('file','')).is_file():E.append(f'missing {p.get("file")}')
if E:print('\n'.join(E));sys.exit(1)
print(f'OK: {len(I)} ideas, {len(P)} prompts')
